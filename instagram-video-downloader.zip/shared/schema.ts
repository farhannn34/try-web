import { z } from "zod";

export const downloadRequestSchema = z.object({
  url: z.string().url("Invalid URL format").refine(
    (url) => {
      const instagramPattern = /^https?:\/\/(www\.)?instagram\.com\/(p|reel|tv)\/[a-zA-Z0-9_-]+\/?(\?.*)?$/;
      return instagramPattern.test(url);
    },
    "Please enter a valid Instagram video URL"
  ),
});

export const downloadResponseSchema = z.object({
  success: z.boolean(),
  downloadUrl: z.string().optional(),
  filename: z.string().optional(),
  error: z.string().optional(),
});

export type DownloadRequest = z.infer<typeof downloadRequestSchema>;
export type DownloadResponse = z.infer<typeof downloadResponseSchema>;
