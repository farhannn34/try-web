import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { downloadRequestSchema, type DownloadRequest, type DownloadResponse } from "@shared/schema";
import { Download, Info, CheckCircle, AlertCircle, Lock, Zap, Shield } from "lucide-react";

export default function Home() {
  const { toast } = useToast();
  const [downloadUrl, setDownloadUrl] = useState<string | null>(null);
  const [filename, setFilename] = useState<string | null>(null);

  const form = useForm<DownloadRequest>({
    resolver: zodResolver(downloadRequestSchema),
    defaultValues: {
      url: "",
    },
  });

  const downloadMutation = useMutation({
    mutationFn: async (data: DownloadRequest): Promise<DownloadResponse> => {
      const response = await apiRequest("POST", "/api/download", data);
      return response.json();
    },
    onSuccess: (data) => {
      if (data.success && data.downloadUrl) {
        setDownloadUrl(data.downloadUrl);
        setFilename(data.filename || "instagram_video.mp4");
        toast({
          title: "Success!",
          description: "Video is ready for download",
        });
      } else {
        toast({
          title: "Error",
          description: data.error || "Failed to process video",
          variant: "destructive",
        });
      }
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to download video",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: DownloadRequest) => {
    setDownloadUrl(null);
    setFilename(null);
    downloadMutation.mutate(data);
  };

  const handleDownload = () => {
    if (downloadUrl && filename) {
      const link = document.createElement("a");
      link.href = downloadUrl;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border">
        <div className="max-w-4xl mx-auto px-4 py-6">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-foreground mb-2">
              Instagram Video Downloader
            </h1>
            <p className="text-muted-foreground">Free, fast, and reliable video downloads</p>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-2xl mx-auto px-4 py-8">
        {/* Instruction Card */}
        <Card className="mb-8">
          <CardContent className="p-6">
            <div className="flex items-start space-x-3">
              <div className="flex-shrink-0 mt-1">
                <Info className="w-5 h-5 text-primary" />
              </div>
              <div>
                <h2 className="text-lg font-semibold text-foreground mb-2">How it works</h2>
                <p className="text-muted-foreground mb-3">
                  Paste the Instagram link below to download your video instantly for free.
                </p>
                <div className="space-y-2 text-sm text-muted-foreground">
                  <div className="flex items-center space-x-2">
                    <span className="w-5 h-5 bg-primary text-primary-foreground rounded-full text-xs flex items-center justify-center font-medium">
                      1
                    </span>
                    <span>Copy Instagram video URL</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="w-5 h-5 bg-primary text-primary-foreground rounded-full text-xs flex items-center justify-center font-medium">
                      2
                    </span>
                    <span>Paste it in the field below</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="w-5 h-5 bg-primary text-primary-foreground rounded-full text-xs flex items-center justify-center font-medium">
                      3
                    </span>
                    <span>Click download and save your video</span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Download Form */}
        <Card>
          <CardContent className="p-6">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="url"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Instagram Video URL</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <Input
                            placeholder="https://www.instagram.com/p/..."
                            {...field}
                            data-testid="input-video-url"
                            className="pr-10"
                          />
                          <div className="absolute inset-y-0 right-0 flex items-center pr-3">
                            <svg className="w-5 h-5 text-muted-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"></path>
                            </svg>
                          </div>
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Button
                  type="submit"
                  className="w-full"
                  disabled={downloadMutation.isPending}
                  data-testid="button-download"
                >
                  {downloadMutation.isPending ? (
                    <>
                      <div className="w-5 h-5 border-2 border-primary-foreground border-t-transparent rounded-full animate-spin mr-2" />
                      Processing...
                    </>
                  ) : (
                    <>
                      <Download className="w-5 h-5 mr-2" />
                      Download Video
                    </>
                  )}
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>

        {/* Success State with Download */}
        {downloadUrl && (
          <Card className="mt-6">
            <CardContent className="p-6">
              <div className="text-center">
                <CheckCircle className="w-12 h-12 text-green-600 mx-auto mb-3" />
                <h3 className="text-lg font-medium text-foreground mb-2">Video Ready!</h3>
                <p className="text-muted-foreground mb-4">Your video has been processed and is ready for download.</p>
                <Button onClick={handleDownload} data-testid="button-download-file">
                  <Download className="w-4 h-4 mr-2" />
                  Download MP4
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Features List */}
        <div className="mt-12 grid md:grid-cols-3 gap-6">
          <div className="text-center">
            <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-3">
              <Lock className="w-6 h-6 text-primary" />
            </div>
            <h3 className="font-medium text-foreground mb-1">100% Free</h3>
            <p className="text-sm text-muted-foreground">No registration or payment required</p>
          </div>
          <div className="text-center">
            <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-3">
              <Zap className="w-6 h-6 text-primary" />
            </div>
            <h3 className="font-medium text-foreground mb-1">Fast Downloads</h3>
            <p className="text-sm text-muted-foreground">High-speed processing and downloads</p>
          </div>
          <div className="text-center">
            <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-3">
              <Shield className="w-6 h-6 text-primary" />
            </div>
            <h3 className="font-medium text-foreground mb-1">Safe & Secure</h3>
            <p className="text-sm text-muted-foreground">No data stored, completely private</p>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-card border-t border-border mt-16">
        <div className="max-w-4xl mx-auto px-4 py-8">
          <div className="text-center text-sm text-muted-foreground">
            <p className="mb-2">Instagram Video Downloader - Free & Fast</p>
            <p>This tool respects Instagram's terms of service. Only download videos you have permission to use.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
