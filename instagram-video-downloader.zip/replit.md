# Instagram Video Downloader

## Overview

This is a full-stack web application built to download Instagram videos. The application provides a simple interface where users can paste Instagram video URLs and download the videos directly to their device. The frontend is built with React and modern UI components, while the backend uses Express.js with video processing capabilities through yt-dlp.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript for type safety and modern development
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query (React Query) for server state management and caching
- **Form Handling**: React Hook Form with Zod validation for robust form validation
- **UI Framework**: Radix UI components with Tailwind CSS for consistent, accessible design
- **Build Tool**: Vite for fast development and optimized production builds

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ESM modules for modern JavaScript features
- **Video Processing**: yt-dlp integration for Instagram video downloading
- **File Management**: Temporary file storage with automated cleanup
- **API Design**: RESTful endpoints with standardized error handling

### Database & ORM
- **Database**: PostgreSQL configured for production use
- **ORM**: Drizzle ORM with type-safe database operations
- **Migrations**: Drizzle Kit for database schema management
- **Connection**: Neon Database serverless PostgreSQL driver

### Validation & Type Safety
- **Schema Validation**: Zod for runtime type checking and validation
- **Shared Types**: Common schema definitions between frontend and backend
- **TypeScript**: End-to-end type safety across the entire application

### Styling & UI
- **CSS Framework**: Tailwind CSS with CSS variables for theming
- **Component Library**: Shadcn/ui components built on Radix UI primitives
- **Design System**: Consistent spacing, colors, and typography through CSS custom properties
- **Responsive Design**: Mobile-first approach with responsive breakpoints

### Development & Build
- **Development Server**: Vite dev server with HMR and React Fast Refresh
- **Production Build**: Optimized bundling with code splitting
- **TypeScript Compilation**: Strict type checking with modern target
- **Path Resolution**: Absolute imports with custom path aliases

## External Dependencies

### Core Framework Dependencies
- **@tanstack/react-query**: Server state management and caching
- **wouter**: Lightweight React routing
- **react-hook-form**: Form state management and validation
- **@hookform/resolvers**: Integration between React Hook Form and Zod

### UI & Styling
- **@radix-ui/react-***: Accessible UI primitives for all interactive components
- **tailwindcss**: Utility-first CSS framework
- **class-variance-authority**: Type-safe CSS class variants
- **clsx**: Conditional CSS class composition
- **lucide-react**: Modern icon library

### Database & ORM
- **drizzle-orm**: Type-safe database ORM
- **drizzle-zod**: Zod integration for Drizzle schemas
- **@neondatabase/serverless**: PostgreSQL database driver
- **drizzle-kit**: Database migration and schema management

### Video Processing
- **yt-dlp**: External binary for downloading videos from Instagram and other platforms
- **child_process**: Node.js module for executing external commands

### Development Tools
- **vite**: Build tool and development server
- **typescript**: Static type checking
- **tsx**: TypeScript execution for development
- **esbuild**: Fast JavaScript bundler for production builds

### Utilities
- **zod**: Runtime type validation and schema definition
- **date-fns**: Date manipulation utilities
- **nanoid**: Unique ID generation
- **cmdk**: Command palette component