import type { Express } from "express";
import { createServer, type Server } from "http";
import { z } from "zod";
import { downloadRequestSchema } from "@shared/schema";
import { exec } from "child_process";
import { promisify } from "util";
import { randomUUID } from "crypto";
import { existsSync, unlinkSync, createReadStream, mkdirSync } from "fs";
import path from "path";

const execAsync = promisify(exec);

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Instagram video download endpoint
  app.post("/api/download", async (req, res) => {
    try {
      // Validate request body
      const { url } = downloadRequestSchema.parse(req.body);

      // Extract video ID from Instagram URL
      const match = url.match(/\/(p|reel|tv)\/([a-zA-Z0-9_-]+)/);
      if (!match) {
        return res.status(400).json({
          success: false,
          error: "Invalid Instagram URL format"
        });
      }

      const videoId = match[2];
      const filename = `instagram_${videoId}_${randomUUID()}.mp4`;
      const outputPath = path.join(process.cwd(), "temp", filename);

      try {
        // Use yt-dlp to download Instagram video
        // Note: yt-dlp needs to be installed: pip install yt-dlp
        const command = `yt-dlp -f "best[ext=mp4]" -o "${outputPath}" "${url}"`;
        
        const { stdout, stderr } = await execAsync(command, {
          timeout: 30000, // 30 second timeout
        });

        if (!existsSync(outputPath)) {
          throw new Error("Video download failed - file not created");
        }

        // Create download endpoint for the file
        const downloadUrl = `/api/download-file/${filename}`;

        res.json({
          success: true,
          downloadUrl,
          filename: `${videoId}.mp4`
        });

      } catch (downloadError) {
        console.error("Download error:", downloadError);
        
        // Handle specific error cases
        let errorMessage = "Failed to download video. ";
        if (downloadError instanceof Error) {
          const errorStr = downloadError.message.toLowerCase();
          if (errorStr.includes("private")) {
            errorMessage += "This video is private or requires login.";
          } else if (errorStr.includes("not found") || errorStr.includes("404")) {
            errorMessage += "Video not found or URL is invalid.";
          } else if (errorStr.includes("timeout")) {
            errorMessage += "Download timed out. Please try again.";
          } else {
            errorMessage += "Please check the URL and try again.";
          }
        }

        res.status(400).json({
          success: false,
          error: errorMessage
        });
      }

    } catch (error) {
      console.error("Validation error:", error);
      if (error instanceof z.ZodError) {
        const firstError = error.errors[0];
        res.status(400).json({
          success: false,
          error: firstError.message
        });
      } else {
        res.status(500).json({
          success: false,
          error: "Internal server error"
        });
      }
    }
  });

  // File download endpoint
  app.get("/api/download-file/:filename", (req, res) => {
    const { filename } = req.params;
    const filePath = path.join(process.cwd(), "temp", filename);

    if (!existsSync(filePath)) {
      return res.status(404).json({
        success: false,
        error: "File not found"
      });
    }

    // Set headers for file download
    res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
    res.setHeader("Content-Type", "video/mp4");

    // Stream the file
    const fileStream = createReadStream(filePath);
    
    fileStream.pipe(res);
    
    // Clean up file after download
    fileStream.on("end", () => {
      setTimeout(() => {
        try {
          if (existsSync(filePath)) {
            unlinkSync(filePath);
          }
        } catch (cleanupError) {
          console.error("File cleanup error:", cleanupError);
        }
      }, 5000); // Delete after 5 seconds
    });

    fileStream.on("error", (error) => {
      console.error("File stream error:", error);
      if (!res.headersSent) {
        res.status(500).json({
          success: false,
          error: "Failed to download file"
        });
      }
    });
  });

  // Create temp directory if it doesn't exist
  const tempDir = path.join(process.cwd(), "temp");
  if (!existsSync(tempDir)) {
    mkdirSync(tempDir, { recursive: true });
  }

  const httpServer = createServer(app);
  return httpServer;
}
