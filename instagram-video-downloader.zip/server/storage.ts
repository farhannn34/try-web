import { randomUUID } from "crypto";

// Simple in-memory storage for tracking downloads (if needed)
export interface IStorage {
  // Add any storage methods you might need for tracking downloads
  // Currently keeping it minimal as per requirements
}

export class MemStorage implements IStorage {
  private downloads: Map<string, any>;

  constructor() {
    this.downloads = new Map();
  }

  // Add storage methods here if needed for download tracking
}

export const storage = new MemStorage();
